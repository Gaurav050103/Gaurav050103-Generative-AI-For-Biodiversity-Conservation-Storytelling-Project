import streamlit as st
import os

# To use the Google API, you will need to set up your API key.
# This app uses an environment variable for security.
# You can set it using `os.environ["GEMINI_API_KEY"] = "YOUR_API_KEY"` or in Streamlit's secrets.toml file.
# import google.generativeai as genai

# The following is a placeholder for the actual API call logic.
# In a real project, you would uncomment the genai import and use it.
# This implementation will return a mock story for demonstration purposes.

# --- Core Application Logic (app.py) ---

# The following code simulates the core functionality of the AI.
# In a full implementation, this function would call the actual Gemini API.
def generate_story(animal_name, region, conservation_topic, style):
    """
    This function simulates the generation of a biodiversity conservation story
    using a generative AI model. It is designed to be a placeholder for a real
    API call to a model like Google's Gemini.

    Args:
        animal_name (str): The name of the animal for the story.
        region (str): The geographical region for the story.
        conservation_topic (str): The specific conservation topic to focus on.
        style (str): The narrative style for the story.

    Returns:
        str: A generated story about the animal's conservation.
    """
    # A simplified, hardcoded response to demonstrate the application's flow.
    # Replace this with your actual API call.
    story = f"""
    ### The Tale of the {animal_name} in {region}

    In the heart of the lush {region} lies a story of resilience and hope. The majestic {animal_name} once faced an uncertain future, their numbers dwindling due to the very real threat of {conservation_topic}. These gentle giants, with their intricate patterns and soulful eyes, are a keystone species, vital to the health of their ecosystem.

    The local communities and conservationists, recognizing the profound importance of the {animal_name}, rallied together. Through tireless efforts, they established protected reserves, campaigned for sustainable land use, and launched educational programs to foster a deeper understanding of the animal's plight.

    The path to recovery was not easy. It was a journey of small victories and hard-won progress. But with each passing year, the population of the {animal_name} has slowly begun to climb, a testament to the power of collective action and the unwavering belief that we can coexist with nature. This story serves as a beacon of hope, a reminder that the fate of our planet's biodiversity rests in our hands, and that through shared dedication, we can write a new, more hopeful chapter for every species on Earth.
    """
    return story

# --- User Interface (UI) in Streamlit ---

st.set_page_config(
    page_title="Biodiversity Conservation Storyteller",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("Generative AI for Biodiversity Conservation Storytelling 🌿")
st.markdown(
    """
    <p style="text-align: center; font-size: 1.2rem; color: #555;">
    This application generates powerful narratives about wildlife and conservation,
    designed to raise awareness and inspire action. Simply provide some details and
    let our AI craft a compelling story.
    </p>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("Story Details")
    animal_name = st.text_input("Enter the animal's name", "Siberian Tiger")
    region = st.text_input("Enter the geographical region", "Amur-Heilong River Basin")
    conservation_topic = st.selectbox(
        "Choose a conservation topic",
        (
            "Habitat Loss",
            "Illegal Wildlife Trade",
            "Climate Change Impact",
            "Human-Wildlife Conflict",
            "Pollution",
        ),
    )
    style = st.selectbox(
        "Choose a narrative style",
        (
            "Informative",
            "Poetic",
            "First-Person (from a researcher's perspective)",
            "Fable",
        ),
    )
    generate_button = st.button("Generate Story", type="primary")

# --- Story Generation and Display ---
if generate_button:
    if not animal_name or not region:
        st.error("Please provide an animal name and a region.")
    else:
        with st.spinner("Crafting your story... this may take a moment."):
            story = generate_story(animal_name, region, conservation_topic, style)
            if story:
                st.subheader("Your Conservation Story")
                st.markdown(story, unsafe_allow_html=True)
                st.success("Story generated successfully!")
            else:
                st.error("Failed to generate the story. Please try again.")

# --- Footer or Additional Info ---
st.markdown("---")
st.markdown(
    """
    <div style="text-align: center; font-size: 0.9rem; color: #777;">
    A final-year project on the intersection of AI and environmental science.
    </div>
    """,
    unsafe_allow_html=True,
)

# --- Instructions for students wanting to separate files ---
# In a real project, you would split this code into multiple files for better organization:
# 1. `app.py`: Contains the Streamlit UI and core app logic.
# 2. `utils.py`: Contains utility functions, like the `generate_story` function,
#    which would handle the API calls to the generative model. You would import it as `from utils import generate_story`.
# 3. `requirements.txt`: A simple text file listing all the Python libraries
#    required to run the project. For this app, it would be:
#    - `streamlit`
#    - `google-generativeai` (if you were using the real API)
# This modular approach is standard for larger projects and demonstrates good practice.
