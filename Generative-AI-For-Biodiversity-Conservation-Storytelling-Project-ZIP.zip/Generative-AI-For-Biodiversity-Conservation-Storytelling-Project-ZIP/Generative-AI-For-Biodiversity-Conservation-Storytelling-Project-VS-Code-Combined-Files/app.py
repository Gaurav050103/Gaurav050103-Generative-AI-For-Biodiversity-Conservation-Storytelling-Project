import streamlit as st
from story_generator import generate_story

# --- Page Configuration ---
st.set_page_config(
    page_title="Biodiversity Conservation AI",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- UI Components ---
st.title("🌿 The Biodiversity AI Storyteller")
st.markdown(
    """
    <div style="background-color:#F0FFF0;padding:10px;border-radius:10px;margin-bottom:20px;">
    <p style="font-size:18px;color:#333;font-style:italic;">
    Crafting compelling narratives to ignite passion for conservation.
    </p>
    </div>
    """,
    unsafe_allow_html=True
)

# Sidebar for user input
st.sidebar.header("Customize Your Story")

# API key input
api_key = st.sidebar.text_input(
    "Enter your Google AI Studio API Key",
    type="password"
)
st.sidebar.markdown(
    "[Get your API Key here](https://aistudio.google.com/app/apikey)"
)

# Story parameters
topic = st.sidebar.text_input(
    "What's your story about?",
    placeholder="e.g., The life of a sea turtle",
    key="topic_input"
)

style = st.sidebar.selectbox(
    "Choose a storytelling style:",
    ["A factual documentary", "A gripping adventure tale", "An inspiring children's story"],
    key="style_select"
)

length = st.sidebar.selectbox(
    "Select the story length:",
    ["Short (1-2 paragraphs)", "Medium (3-4 paragraphs)", "Long (5-6 paragraphs)"],
    key="length_select"
)

generate_button = st.sidebar.button("Generate Story", type="primary")

# --- Main Content Area ---
st.header("Your Story")

story_placeholder = st.empty()
sources_placeholder = st.empty()

# --- Story Generation Logic ---
if generate_button:
    if not api_key:
        st.error("Please enter your Google AI Studio API Key to continue.")
    elif not topic:
        st.error("Please enter a topic for your story.")
    else:
        # Display a spinner while generating the story
        with st.spinner("Creating your biodiversity story..."):
            try:
                story, sources = generate_story(api_key, topic, style, length)
                
                # Display the generated story
                story_placeholder.text_area(
                    "Generated Story",
                    story,
                    height=500
                )
                
                # Display the sources if available
                if sources:
                    sources_placeholder.subheader("Sources")
                    for i, source in enumerate(sources):
                        sources_placeholder.markdown(
                            f"**{i+1}.** [{source.get('title', 'Untitled')}]({source.get('uri', '#')})"
                        )
                else:
                    sources_placeholder.info("No external sources were used for this story.")
            
            except Exception as e:
                st.error(f"An error occurred: {e}")