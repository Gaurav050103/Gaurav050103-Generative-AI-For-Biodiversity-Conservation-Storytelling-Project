import google.generativeai as genai
import json

def generate_story(api_key, topic, style, length):
    """
    Generates a story about a biodiversity conservation topic using the Gemini API.
    
    Args:
        api_key (str): The Google AI Studio API key.
        topic (str): The subject of the story (e.g., "Siberian Tiger").
        style (str): The storytelling style (e.g., "A gripping adventure tale").
        length (str): The desired length of the story.
        
    Returns:
        tuple: A tuple containing the generated story and its source citations.
    """
    # The API key is set here for the generative AI model
    genai.configure(api_key=api_key)

    # Construct the user prompt, combining all user inputs
    full_prompt = (
        f"Generate a story about the biodiversity conservation topic: {topic}. "
        f"The story should be in the style of: {style}. "
        f"The length should be {length}. "
        "The story must be factually accurate, educational, and engaging."
    )

    try:
        # Define the system instruction for the AI's persona
        system_prompt = (
            "You are a world-class biodiversity conservationist and an expert storyteller. "
            "Your task is to craft compelling narratives that highlight the importance of "
            "conserving nature and protecting endangered species. Ensure all generated "
            "content is factually correct and inspiring."
        )

        # Construct the payload for the API call
        payload = {
            "contents": [{"parts": [{"text": full_prompt}]}],
            "tools": [{"google_search": {}}],  # Enable Google Search grounding
            "systemInstruction": {"parts": [{"text": system_prompt}]}
        }

        # API endpoint and model
        api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key={api_key}"

        # Make the POST request to the API
        import requests
        response = requests.post(api_url, json=payload)
        response.raise_for_status() # Raise an exception for bad status codes

        result = response.json()
        candidate = result.get("candidates", [])[0]
        text_part = candidate.get("content", {}).get("parts", [])[0]
        generated_text = text_part.get("text", "")

        # Extract grounding sources (citations)
        grounding_metadata = candidate.get("groundingMetadata", {})
        sources = []
        if grounding_metadata and grounding_metadata.get("groundingAttributions"):
            sources = [
                {
                    "title": attribution.get("web", {}).get("title"),
                    "uri": attribution.get("web", {}).get("uri")
                }
                for attribution in grounding_metadata["groundingAttributions"]
            ]
        
        return generated_text, sources

    except Exception as e:
        return f"An error occurred: {e}", []